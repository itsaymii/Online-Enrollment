from django.urls import path
from . import views

urlpatterns =[
    # path('students/', views.students, name = "Students"),
    # path('aimee/', views.aimee, name = "Aimee"),
    # path('rose/', views.rose, name = "Rose"),
    # path('me/', views.me, name = "Me"),
]