from django.shortcuts import render
from django.http import HttpResponse


# def students (request):
#     return HttpResponse ("This is the Students")

# def aimee (request):
#     return HttpResponse ("Aimee")

# def rose (request):
#     return HttpResponse ("Rose")

# def me (request):
#     return HttpResponse ("Me")

# Create your views here.
